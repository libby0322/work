/* 1. 변수 셋으로 만들기 2. 변수 하나로 만들기

<div class="box2">
    <div class="gimpo">김포</div>
</div>
*/
var str = "<table border='1' width='100'>";
str += "<tr>";
str += "<td>1</td><td>2</td><td>3</td>";
str += "</tr>";
str += "</table>";

document.write(str);

//result = num1 - num2;
//document.write(result,"<br>");

//result = num1 * num2;
//document.write(result,"<br>");

//result = num1 / num2;
//document.write(result,"<br>");

//result = num1 % num2;
//document.write(result,"<br>");


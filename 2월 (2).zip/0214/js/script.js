var age = prompt("당신의 나이는?","0");
if(age>=20){당신은 성인입니다.}
else(age)